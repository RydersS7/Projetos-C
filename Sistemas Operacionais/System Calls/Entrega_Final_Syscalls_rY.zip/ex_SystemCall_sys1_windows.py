import msvcrt

print("Digite uma string: ", end="", flush=True)

buffer = bytearray()
while True:
    ch = msvcrt.getwch()
    if ch == '\r':  # Enter no Windows
        break
    buffer.extend(ch.encode('utf-8'))

print("\nString invertida:", buffer.decode('utf-8')[::-1])