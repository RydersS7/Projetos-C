#include <windows.h>
#include <stdio.h>

int main() {
    HANDLE hStdin = GetStdHandle(STD_INPUT_HANDLE);
    HANDLE hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD bytesRead, bytesWritten;
    char buffer[256];

    WriteFile(hStdout, "Digite uma string: ", 18, &bytesWritten, NULL);
    ReadFile(hStdin, buffer, sizeof(buffer), &bytesRead, NULL);

    // Remover CRLF
    if (bytesRead > 0 && buffer[bytesRead - 1] == '\n') bytesRead--;
    if (bytesRead > 0 && buffer[bytesRead - 1] == '\r') bytesRead--;

    WriteFile(hStdout, "String invertida: ", 17, &bytesWritten, NULL);
    for (int i = bytesRead - 1; i >= 0; i--) {
        WriteFile(hStdout, &buffer[i], 1, &bytesWritten, NULL);
    }
    WriteFile(hStdout, "\n", 1, &bytesWritten, NULL);

    return 0;
}
