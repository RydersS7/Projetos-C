# Leitura de string com input() e impressão com print()

s = input("Digite uma string: ")           # <-- Função de alto nível, semelhante ao fgets()
print("String invertida:", s[::-1])        # <-- Fatiamento para inverter a string